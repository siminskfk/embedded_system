// ** Test File for Assignment 10 - group 4 **

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define TEXTLCD_BASE	    	0xbc
#define TEXTLCD_COMMAND_SET     _IOW(TEXTLCD_BASE,0,int)
#define TEXTLCD_FUNCTION_SET    _IOW(TEXTLCD_BASE,1,int)
#define TEXTLCD_DISPLAY_CONTROL _IOW(TEXTLCD_BASE,2,int)
#define TEXTLCD_CURSOR_SHIFT    _IOW(TEXTLCD_BASE,3,int)
#define TEXTLCD_ENTRY_MODE_SET  _IOW(TEXTLCD_BASE,4,int)
#define TEXTLCD_RETURN_HOME     _IOW(TEXTLCD_BASE,5,int)
#define TEXTLCD_CLEAR           _IOW(TEXTLCD_BASE,6,int)
#define TEXTLCD_DD_ADDRESS		_IOW(TEXTLCD_BASE,7,int)
#define TEXTLCD_WRITE_BYTE      _IOW(TEXTLCD_BASE,8,int)

 // TextLCD
struct strcommand_varible {
	char rows;
	char nfonts;
	char display_enable;
	char cursor_enable;
	char nblink;
	char set_screen;
	char set_rightshit;
	char increase;
	char nshift;
	char pos;
	char command;
	char strlength;
	char buf[16];
};

// Timer Setting(Start 0)
unsigned int timer = 0;
unsigned int time = 0;

int main(int argc, char** argv)
{
	int i, dev1, dev2, dev3;
	unsigned short dipsw[2];
	char buf0[16] = "Time is running!";
	char buf1[16] = "Now switch is ";
	char buf2[16] = "Stop Time ";
	char buf3[16] = "";

	// TextLCD
	struct strcommand_varible strcommand;
	strcommand.rows = 0;
	strcommand.nfonts = 0;
	strcommand.display_enable = 1;
	strcommand.cursor_enable = 0;
	strcommand.nblink = 0;
	strcommand.set_screen = 0;
	strcommand.set_rightshit = 1;
	strcommand.increase = 1;
	strcommand.nshift = 0;
	strcommand.pos = 10;
	strcommand.command = 1;
	strcommand.strlength = 16;

	// Open device driver file
	dev1 = open("/dev/textlcd", O_WRONLY | O_NDELAY);
	dev2 = open("/dev/segment", O_RDWR | O_SYNC);
	dev3 = open("/dev/dipsw", O_RDONLY);

	// Device open error
	if (dev1 < 0) {
		printf("textlcd open failed\n");
		exit(-1);
	}
	else if (dev2 < 0) {
		printf("segment open failed\n");
		exit(-1);
	}
	else if (dev3 < 0) {
		printf("dipsw open failed\n");
		exit(-1);
	}
	else
		printf("device open success\n");

	// Timer start
	while (1) {
		// Check dipsw for mode of timer(0x08:start / else:stop(reset))
		read(dev3, &dipsw, 4);

		if (dipsw[0] == 0x08) {
			strcommand.pos = 0;
			ioctl(dev1, TEXTLCD_DD_ADDRESS, &strcommand, 32);
			write(dev1, buf0, 16);
			usleep(500000);
			strcommand.pos = 40;
			ioctl(dev1, TEXTLCD_DD_ADDRESS, &strcommand, 32);
			sprintf(buf3, "%d", dipsw[0]);
			strcat(buf1, buf3);
			write(dev1, buf1, 16);

			// Time is running
			if (timer = 86400)
				timer = 0;
			time = (timer / 3600) * 10000 + ((timer % 3600) / 60) * 100 + timer % 60;

			for (i = 0; i < 140; i++)
				write(dev2, &time, 4);
			timer++;

			ioctl(dev1, TEXTLCD_CLEAR, &strcommand, 32);
		}

		// Timer stop and reset
		else {
			strcommand.pos = 0;
			ioctl(dev1, TEXTLCD_DD_ADDRESS, &strcommand, 32);
			write(dev1, buf1, 16);
			usleep(500000);

			strcommand.pos = 40;
			ioctl(dev1, TEXTLCD_DD_ADDRESS, &strcommand, 32);
			sprintf(buf3, "%d", time);
			strcat(buf1, buf3);
			write(dev1, buf2, 16);

			// Time reset
			timer = 0;
			time = 0;

			write(dev2, &time, 4);
			printf("Stop time is %06d.\nIf you want to restart, change switch to 0x08\n", time);

			ioctl(dev1, TEXTLCD_CLEAR, &strcommand, 32);
		}
	}

	// Close device driver file
	close(dev1);
	close(dev2);
	close(dev3);

	return 0;
}

