/*
 * TextLCD Device Driver test Program
 *  Hanback Electronics Co.,ltd
 * File : textlcd_test.c
 * Date : April,2009
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define TEXTLCD_BASE	    	0xbc
#define TEXTLCD_COMMAND_SET     _IOW(TEXTLCD_BASE,0,int)
#define TEXTLCD_FUNCTION_SET    _IOW(TEXTLCD_BASE,1,int)
#define TEXTLCD_DISPLAY_CONTROL _IOW(TEXTLCD_BASE,2,int)
#define TEXTLCD_CURSOR_SHIFT    _IOW(TEXTLCD_BASE,3,int)
#define TEXTLCD_ENTRY_MODE_SET  _IOW(TEXTLCD_BASE,4,int)
#define TEXTLCD_RETURN_HOME     _IOW(TEXTLCD_BASE,5,int)
#define TEXTLCD_CLEAR           _IOW(TEXTLCD_BASE,6,int)
#define TEXTLCD_DD_ADDRESS	_IOW(TEXTLCD_BASE,7,int)
#define TEXTLCD_WRITE_BYTE      _IOW(TEXTLCD_BASE,8,int)

// TextLCD
struct strcommand_varible {
	char rows;
	char nfonts;
	char display_enable;
	char cursor_enable;
	char nblink;
	char set_screen;
	char set_rightshit;
	char increase;
	char nshift;
	char pos;
	char command;
	char strlength;
	char buf[16];
};

// argc :
int main(int argc, char **argv)
{
	int i,dev;
	char buf0[16]	= "Welcome to the  ";
	char buf1[16] 	= "Embedded World!!";
	char buf2[16]	= "    HANBACK     ";
	char buf3[16] 	= "  Electronics   ";

	// TextLCD
	struct strcommand_varible strcommand;
	strcommand.rows = 0;		
	strcommand.nfonts = 0;		
	strcommand.display_enable = 1;		
	strcommand.cursor_enable = 0;		
	strcommand.nblink = 0;		
	strcommand.set_screen = 0;		
	strcommand.set_rightshit = 1;		
	strcommand.increase = 1;		
	strcommand.nshift = 0;		
	strcommand.pos = 10;		
	strcommand.command = 1;		
	strcommand.strlength = 16;		
	
	// /dev/textlcd
	// dev
	dev = open("/dev/textlcd", O_WRONLY|O_NDELAY );
	
	if (dev != -1) {
		write(dev,buf0,16);
		usleep(500000);
		strcommand.pos = 40;
		ioctl(dev,TEXTLCD_DD_ADDRESS,&strcommand,32);
		write(dev,buf1,16);
		sleep(1);
		
		ioctl(dev,TEXTLCD_CLEAR,&strcommand,32);
		
		strcommand.pos = 0;
		ioctl(dev,TEXTLCD_DD_ADDRESS,&strcommand,32);
		for(i=0;i<16;i++) {
			memcpy(&strcommand.buf[0],&buf2[i],1);
			strcommand.buf[0]=buf2[i];
			ioctl(dev,TEXTLCD_WRITE_BYTE,&strcommand,32);
		}		
		usleep(500000);
		
		strcommand.pos = 40;
		ioctl(dev,TEXTLCD_DD_ADDRESS,&strcommand,32);
		for(i=0;i<16;i++) {
			memcpy(&strcommand.buf[0],&buf3[i],1);
			strcommand.buf[0]=buf3[i];
			ioctl(dev,TEXTLCD_WRITE_BYTE,&strcommand,32);
		}
	
		close(dev);
	} else {
		printf( "application : Device Open ERROR!\n");
		exit(1);
	}
	return 0;
}

