#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>

#define EVENT_BUF_NUM 64

int main(void) {
    int i, quit = 1;
    int fd = -1; /* the file descriptor for the device */
    size_t read_bytes; // 몇 bytes read 했느냐
    struct input_event event_buf[EVENT_BUF_NUM]; // 몇개의 event 까지 한꺼번에 읽느냐

    // Driver File Open
    dev1 = open("/dev/input/event3", O_RDONLY);     // dev1:keypad
    dev2 = open("/dev/dotmatrix", O_WRONLY);        // dev2:dotmatrix

    if (dev1 < 0) {
        printf("Keypad Driver Open Fail!\n");
        exit(1);
    }
    if (dev2 < 0) {
        printf("Dot Matrix Driver Open Fail!\n");
        exit(1);
    }

    printf("press the key button!\n");
    printf("press the key 26 to exit!\n");

    while (quit) {
        // event 발생을 EVENT_BUF_NUM 만큼 읽어들인다.
        read_bytes = read(dev1, event_buf, (sizeof(struct input_event) * EVENT_BUF_NUM));
        if (read_bytes < sizeof(struct input_event)) {
            printf("application : read error!!");
            exit(1);
        }

        for (i = 0; i < (read_bytes / sizeof(struct input_event)); i++) {
            // event type : KEY
            // event value : 0(pressed)
            if ((event_buf[i].type == EV_KEY) && (event_buf[i].value == 0)) {
                printf("\n Button key : %d\n", event_buf[i].code);
                write(dev2, &event_buf[i].code, 4);
                if (event_buf[i].code == 26) {
                    printf("\napplication : Exit Program!! (key = %d)\n", event_buf[i].code);
                    quit = 0;
                }
            }
        }
    }
    // Driver file Close
    close(dev1);
    close(dev2);
    return 0;
}